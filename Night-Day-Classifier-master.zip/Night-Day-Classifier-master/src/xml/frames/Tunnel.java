package xml.frames;

public class Tunnel extends ConfidenceValue{

}
