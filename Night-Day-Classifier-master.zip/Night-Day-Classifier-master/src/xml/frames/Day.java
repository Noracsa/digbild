package xml.frames;

public class Day extends ConfidenceValue{
	
}
