package xml.frames;


public class Night extends ConfidenceValue{
}
