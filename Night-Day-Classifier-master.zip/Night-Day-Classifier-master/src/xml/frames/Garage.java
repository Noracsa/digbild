package xml.frames;

public class Garage extends ConfidenceValue{

}
