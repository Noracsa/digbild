package xml.frames;

public class BadWeather extends ConfidenceValue {

}
